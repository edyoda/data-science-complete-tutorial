from sklearn.ensemble import RandomForestClassifier

class Employee:
    def __init__(self):
        self.model = RandomForestClassifier()
        

    def fit(self,trainX,trainY):
        self.model.fit(trainX,trainY)


    def predict(self,testX):
        return self.model.predict(testX)
