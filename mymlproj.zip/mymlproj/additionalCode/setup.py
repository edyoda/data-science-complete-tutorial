from setuptools import setup

setup( name='MyMlApp', 
       version='0.2dev', 
       packages=['utilities'], 
       include_package_data=False,
       license=''' Creative Commons Attribution-Noncommercial-Share Alike license''', 
       long_description=''' An example of how to package code for Machine Learning''' )
